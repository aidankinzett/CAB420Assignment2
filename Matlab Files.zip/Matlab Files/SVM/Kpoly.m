function kval = Kpoly(u,v,param)

kval = (1+u*v').^param;

