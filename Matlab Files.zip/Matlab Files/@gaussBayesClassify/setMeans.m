function obj = setMeans(obj,m)
% gbc = setMeans(gbc, m) : set the means of the classifier

obj.means = m;

