function obj = setCovars(obj,c)
% gbc = setCovars(gbc, c) : set the covariances of the classifier

obj.covars = c; 

