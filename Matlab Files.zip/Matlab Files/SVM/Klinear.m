function kval = Klinear(u,v,param)

kval = u*v';

